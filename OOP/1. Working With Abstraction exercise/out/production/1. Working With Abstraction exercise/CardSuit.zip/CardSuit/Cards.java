package CardSuit;

public enum Cards {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES
}
